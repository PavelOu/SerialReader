//RF-433MHz-STX882-BME280-sender
/*
Sketch for sending of data from BME280 sensor with RF433MHz technology
Multifunction sensor BME280 for measuring 
 temperature, humidity and air pressure  is used
BME280 project details were addapted 
from https://randomnerdtutorials.com by Riu Santos        
Data are coupled with code for specification of different data
Example : specialised code for temperature is here set to  10 000 000
          and to this code is added temperature (example) 23.45 * 100 = 2345
          if temperature < 0 , the special code is set to 11 000 000
          special code for humidity is set  to 12 000 000
          special code for air press is set to 13 000 000
This RF433 MHz application is based on library and examples 
from  https://github.com/sui77/rc-switch/
Reprogrammed by PavelOu
rewrited from RF-433MHz-STX882-BME280-sender-po-5
version of NodeMcu V1.0 (V2)
*/
// RF 433 library
#include <RCSwitch.h>

//Adafruit library
#include <Wire.h>
#include <Adafruit_BME280.h>
#include <Adafruit_Sensor.h>


String sketchName = "RF-433MHz-STX882-BME280-sender.ino";
const int ledPin = D3;
const int txPin = D5;
byte protocolNr = 2;
long int specialCode = 10000000;
byte nrBits = 32;
int intervalDat = 100; // ms

long int dataInt = 0;

byte dataMode = 0;
char markRx = 0;

bool status;
float temp = 23.45; // examples
float hump = 54.56;
float presp = 1021.89 ;

int timeRep = 30;  //time for repeating of measuring in sec
int timeStep = 1;
bool i2cOn = false;


long int dataPom;

Adafruit_BME280 bme; // I2C => SCL = D1, SDA = D2
//Adafruit_BME280 bme(BME_CS); // hardware SPI
//Adafruit_BME280 bme(BME_CS, BME_MOSI, BME_MISO, BME_SCK); // software SPI

#define SEALEVELPRESSURE_HPA (1013.25)


// creating objekt senderRFe from library
RCSwitch senderRF = RCSwitch();

void printValues()    //for test only
 {
  Serial.print("Temperature = ");
  Serial.print(bme.readTemperature());
  Serial.println(" *C");

  Serial.print("Humidity = ");
  Serial.print(bme.readHumidity());
  Serial.println(" %");

  //Convert temperature to Fahrenheit
  Serial.print("Temperature = ");
  Serial.print(1.8 * bme.readTemperature() + 32);
  Serial.println(" *F");

  Serial.print("Pressure = ");
  Serial.print(bme.readPressure());
  Serial.println(" Pa");

  Serial.print("Pressure = ");
  Serial.print(bme.readPressure() / 100.0F);
  Serial.println(" hPa");

  Serial.print("Approx. Altitude = ");
  Serial.print(bme.readAltitude(SEALEVELPRESSURE_HPA));
  Serial.println(" m");
 }

void setup() 
 {
  Serial.begin(9600);
  while (!Serial)
   {
    delay(1000);
   }
  pinMode(ledPin,OUTPUT);     // this led signalised RF transmission
  digitalWrite(ledPin,HIGH);
  delay(1000);
  digitalWrite(ledPin,LOW);
  Serial.println();
  Serial.println(sketchName);
  Serial.println("RF-OT 433 Mhz sender is starting ...");

// default settings
  // (you can also pass in a Wire library object like &Wire2)
  status = bme.begin(0x76);  
  //status = true;  //for test without BME280 sensor
  if (!status) 
   {
    Serial.println("Could not find a valid BME280 sensor, check wiring!");
   }
  else
   { 
    printValues();  //BME280 test
   } 
  
  temp = 23.45; //for test only
  
  
  // optional set of protocol on nr.2 //must be the some in the receiver
  // senderRF.setProtocol(2);
  // optional set of protocol nr.5
  // senderRF.setRepeatTransmit(5);  //here not used
  protocolNr = 2;
  Serial.print("Protocol: "); 
  Serial.println(protocolNr);
  //testData = 22;
  //Serial.print("Tested data: ");
  //Serial.println(testData);
  specialCode = 10000000;
  Serial.print("special data set: ");
  Serial.println(specialCode);
  nrBits = 32;
  Serial.print("Used nr of bits: ");
  Serial.println(nrBits);
  intervalDat = 100;
  Serial.print("Interval dat: "); //optional
  Serial.println(intervalDat);
  markRx = 0;
  //start with repetition in time 20 sec
  timeRep = 20;
  dataMode = 2;
  senderRF.setProtocol(protocolNr);  
  // start of sending on txPin
  senderRF.enableTransmit(txPin);
  
}

void loop() 
 {
  if (dataMode == 0)
    {
     Serial.println();
     Serial.println(sketchName);
     Serial.println("New settings:");         
     Serial.println("A = data BME only, E = RF data BME, Tint = time for repeting");
     dataMode = 1;
     markRx = 0;
     digitalWrite(ledPin,LOW);  // turn the LED
    }
 if (Serial.available())
    {
     markRx = Serial.read();
     Serial.print("choosed: ");
     Serial.println(markRx);
     timeRep = 0;
     Serial.flush();
     if ( markRx == 65 )    // A
          {
            Serial.println("Data BME");
            //digitalWrite(ledPin, HIGH);  // turn the LED on
            printValues();
            dataMode = 0;               
          }
     /* this section is prepared for tests only
     if ( markRx == 66 )    // B
          {
            String Bstring = Serial.readString();
            Bstring.trim();
            nrBits = Bstring.toInt();
            Serial.print("Bits: ");
            Serial.println(nrBits);
            dataMode = 0;          
          }
     if ( markRx == 67 )    // C
          {
            String Cstring = Serial.readString();
            Cstring.trim();
            specialCode = Cstring.toInt();
            Serial.print("Special code: ");
            Serial.println(specialCode);
            dataMode = 0;
          }
     if ( markRx == 68 )   // D
          {
            // reading end command for sending - example 101 for set on green Led
            String textToSend = Serial.readString();
            dataInt = textToSend.toInt();
            Serial.print("Sending Int Data: ");
            Serial.println(dataInt);
            temp = dataInt / 100.0;
            //digitalWrite(ledPin, HIGH);  // turn the LED on
            dataMode = 2;
          }
      if ( markRx == 77 )   // M
          {
            // reading end command for sending - example 101 for set on green Led
            String textToSend = Serial.readString();
            dataInt = textToSend.toInt();
            Serial.print("Sending Int Data with minus: ");
            Serial.println(dataInt);
            temp = - dataInt / 100.0;
            digitalWrite(ledPin, HIGH);  // turn the LED off
            dataMode = 2;
          }
      if (markRx == 80)  // P
        {
            String Pstring = Serial.readString();
            Pstring.trim();
            protocolNr = Pstring.toInt();
            Serial.print("Protocol: ");
            Serial.println(protocolNr);
            senderRF.setProtocol(protocolNr);
            dataMode = 0;  
           }
       */    
            
     if (markRx == 69) // E 
         {
          Serial.println("Data BME send by RF");
          //digitalWrite(ledPin, HIGH);  // turn the LED on   
          dataMode = 2;                        
         }
     if (markRx == 84)  // T
        {
            String Tstring = Serial.readString();
            Tstring.trim();
            timeRep = Tstring.toInt();
            Serial.print("Time for repeating: ");
            Serial.print(timeRep);
            Serial.println(" in sec");
            senderRF.setProtocol(protocolNr);
            if (timeRep>0)
             {
              dataMode = 2;  
              timeStep = 0;
             }
            else  
             {
              dataMode = 0;
              Serial.println("time zero ??");
             }
           }
     markRx = 0;  
     Serial.flush();
    } 
   if (dataMode == 2 )
      {
        //start of measuring data and RF transmission
        digitalWrite(ledPin,HIGH);
        Serial.print("Temperature = ");
        if (status)
         {
          temp = bme.readTemperature();
         }
        Serial.print(temp);
        Serial.println(" *C");
        if (temp > 0)
         {
          specialCode = 10000000;
          dataPom = temp * 100; // dataPom = 23.45 * 100 = 2345
         }
        else
         {
          specialCode = 11000000;         
          dataPom = (-1) * temp * 100; // dataPom = -1 * - 23.45 * 100 = 2345
         }   
        //dataPom = temp * 100; // dataPom = 23.45 * 100 = 2345
        Serial.print("dataPom = ");
        Serial.println(dataPom);
        dataPom = specialCode + dataPom; //10000000 + 2345 = 10002345
        Serial.print("specialCode + dataPom = ");
        Serial.println(dataPom);        //data are prepared for RF transmission
        senderRF.setProtocol(protocolNr);  
        senderRF.send(dataPom,nrBits);  // data are transfered
        //back recounting (in receiver) example:
        //dataResult = dataPom - specialCode = 10234500 - 10000000 = 234500
        //dataPom = dataPom - dataResult = 10234500 - 234500 = 10000000
        //dataUnit = dataPom / 1000000 = 10000000 / 1000000 = 10
        //dataUnit = 10 => Unit is plus temp
        //dataUnit = 11 => Unit is minus temp etc.
        //temp = dataResult / 10000 = 234500 /10000 = 23.45 *C
        // if dataUnit == 11 => temp = -23.45
        // pause before preparing and transmitting of next data
        delay(intervalDat);        
        Serial.print("Humidity = ");
        if (status)
         {
          hump = bme.readHumidity();
         }
        Serial.print(hump);
        Serial.println(" %");
        specialCode = 12000000;
        dataPom = hump * 100; // dataPom = 43.45 * 100 = 4345
        Serial.print("dataPom = ");
        Serial.println(dataPom);
        dataPom = specialCode + dataPom; //12000000 + 4345 = 12004345
        Serial.print("specialCode + dataPom = ");
        Serial.println(dataPom);
        senderRF.setProtocol(protocolNr);  
        senderRF.send(dataPom,nrBits);
        delay(intervalDat);         
        Serial.print("Pressure in Pa = ");
        if (status)
         {
          presp = bme.readPressure();
         }
        Serial.println(presp);
        Serial.print("Pressure in hPa= ");
        Serial.print( presp / 100.0);
        Serial.println(" hPa");
        specialCode = 13000000;
        dataPom = presp * 10; // dataPom = 10216.78 * 10 = 102167 in deko Pa
        Serial.print("dataPom = ");
        Serial.println(dataPom);
        dataPom = specialCode + dataPom; //13000000 + 102167= 13102167
        Serial.print("specialCode + dataPom = ");
        Serial.println(dataPom);
        senderRF.setProtocol(protocolNr);  
        senderRF.send(dataPom,nrBits);
        /* not used
        Serial.print("Approx. Altitude = ");
        Serial.print(bme.readAltitude(SEALEVELPRESSURE_HPA));
        Serial.println(" m");
        */
        // pause before new transmitting of data
        delay(1000);
        digitalWrite(ledPin,LOW);
        if (timeRep == 0)
         {
          //delay(intervalDat);
          dataMode = 0;
         }
        else
         {
          Serial.print("Time: ");
          Serial.print(timeRep);
          Serial.println(" sec is starting ...");
          timeStep = 0;
          dataMode = 3; 
         }
      } // end of dataMode = 2
   if (dataMode == 3)
      {
          timeStep += 1;
          if (timeStep == timeRep)
           {
            timeStep = 0;
            Serial.println("*");
            Serial.print("Time: ");
            Serial.print(timeRep);
            Serial.println(" is on !");
            dataMode = 2;
           }
          else
           {            
            Serial.print(timeStep);
            Serial.print(",");
            delay(1000); 
           }
      } // end of dataMode = 3        
}
