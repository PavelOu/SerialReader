Protocol RFBME - readme
== = = = = = = = = = = = = = = 
actual version 10
= = = = = = = = =
Date of last finalising : 2026-10-12

Preface :
=========
This readme is for protocol RFBME - version 10 .

I have created this protocol for serial devices what can communicate 
via USB-RS232 like Arduino etc. now special for Arduino Uno

and then with my programs like SerialMeasurer or SerialPlotter 
created in Delphi XE Starter and worked under operation system Windows.

These programs were created and tested by me only on W11 64 bits.
and they were created by Pavel Oupicky, rentier and home worker.
These programs are distributed by author as freeware for end users .   
Author takes no liability towards of any use of his program.

At 23.09. 2026 					Pavel Oupicky

Protocol RFBME
= = = = = = = =

This protocol was created for Arduino Uno or another microcomputers (Mcu)
what can communicate via serial protocols with PC .
Program from PC calls Mcu via RS232 (USB) with commands 
and one expects in Mcu prepared answer.

Used commands and answers in protocol RFBME for program SerialReader
included in sketch RF-433MHz-SRX882-BME280-receiver-1.ino
= = = = = = = = = = = = = = = = = = = = = = = = = = = = =

Command Answer
- - - - - - - - 
NU	*temp,hump,presp,#,	// command is not used
				// data example *23.45,55.67,9985.23,#,

Note:	timeStep is set i RF433 data sender

Example of using commands in program SerialReader15
- - - - - - - - - - - - - - - - - - - - - - - - - -
SerialReader/15/params
Registrace teplot, vlhkosti a tlaku
System Arduino+RF433MHz+BME280
Date:2026-01-08*12:22
Device:Arduino+RF433MHz+BME280
Protocol:RFBME/RF433MHz
Port:Com,3,9600,8,1,0
Timing:Timer=10,Sleep=10,Wait=200,Timeout=100
Inputs:3
1:RFBME/2,0,99.99,1.0/C,Tepm,Temperature
2:RFBME/2,0,99.99,1.0/%,Hum,Humidity
3:RFBME/2,0,999.999,0.1/mbar,Air Pres
Tasks:3
All,N,1,2,3,end		// Name of task,Command(here not used),inputs,end
TH,N,1,2,end
AP,N,3,end
Measured interval:0
Data:Data
Help:Help\DataSerial10-help.txt
Graf-par:Grp\Grf-DataSerial-RFBME-en.grp
end


= = = * * * end of readme * * * = = = 


